﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1_Login : Form
    {
        public Form1_Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            String user, password;
            user = txt_UserID.Text;
            password =txt_Password.Text;
            if (user == "NLDoctor" && password == "NL@Doc")
            {
                WindowsFormsApplication1.Forms.Doctor_Link.Form1_DocLink newform = new WindowsFormsApplication1.Forms.Doctor_Link.Form1_DocLink();
                newform.Show();
                    this.Hide();
                MessageBox.Show("Login Succesfull!!");
            }
            if (user == "NLNurse" && password == "NL@Nurse")
            {
                WindowsFormsApplication1.Forms.Nurse_Link.Form1_NurseLink newform = new WindowsFormsApplication1.Forms.Nurse_Link.Form1_NurseLink();
                newform.Show();
                this.Hide();
                MessageBox.Show("Login Succesfull!!");
            }
            else
            {
               MessageBox.Show("Login Failed!!");
            }
        }

        private void checkBox1_ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1_ShowPass.Checked)
                {
                    txt_Password.UseSystemPasswordChar = false;
                }
            else 
                {
                    txt_Password.UseSystemPasswordChar = true;
                }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
               {
                    Application.Exit();
               }
        }
    }
}
