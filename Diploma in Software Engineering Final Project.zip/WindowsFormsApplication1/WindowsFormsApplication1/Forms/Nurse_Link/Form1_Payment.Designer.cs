﻿namespace WindowsFormsApplication1.Forms
{
    partial class Form1_Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Pay = new System.Windows.Forms.Label();
            this.lbl_HospitalMangementSystem = new System.Windows.Forms.Label();
            this.lbl_PatRegNo = new System.Windows.Forms.Label();
            this.lbl_TotAmt = new System.Windows.Forms.Label();
            this.lbl_PatName = new System.Windows.Forms.Label();
            this.lbl_Treatment = new System.Windows.Forms.Label();
            this.lbl_PayMethod = new System.Windows.Forms.Label();
            this.lbl_CardType = new System.Windows.Forms.Label();
            this.lbl_DocFee = new System.Windows.Forms.Label();
            this.lbl_HosCh = new System.Windows.Forms.Label();
            this.lbl_TreatmentFee = new System.Windows.Forms.Label();
            this.txt_PatRegNo = new System.Windows.Forms.TextBox();
            this.txt_PatNme = new System.Windows.Forms.TextBox();
            this.txt_TreatFee = new System.Windows.Forms.TextBox();
            this.txt_TeatName = new System.Windows.Forms.TextBox();
            this.txt_Tot = new System.Windows.Forms.TextBox();
            this.txt_HosFee = new System.Windows.Forms.TextBox();
            this.txt_DocFee = new System.Windows.Forms.TextBox();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.cmb_PayMeth = new System.Windows.Forms.ComboBox();
            this.cmb_CardType = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Pay);
            this.panel1.Controls.Add(this.lbl_HospitalMangementSystem);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(529, 89);
            this.panel1.TabIndex = 2;
            // 
            // lbl_Pay
            // 
            this.lbl_Pay.AutoSize = true;
            this.lbl_Pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pay.Location = new System.Drawing.Point(174, 48);
            this.lbl_Pay.Name = "lbl_Pay";
            this.lbl_Pay.Size = new System.Drawing.Size(149, 37);
            this.lbl_Pay.TabIndex = 1;
            this.lbl_Pay.Text = "Payment";
            // 
            // lbl_HospitalMangementSystem
            // 
            this.lbl_HospitalMangementSystem.AutoSize = true;
            this.lbl_HospitalMangementSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalMangementSystem.Location = new System.Drawing.Point(3, 2);
            this.lbl_HospitalMangementSystem.Name = "lbl_HospitalMangementSystem";
            this.lbl_HospitalMangementSystem.Size = new System.Drawing.Size(519, 42);
            this.lbl_HospitalMangementSystem.TabIndex = 0;
            this.lbl_HospitalMangementSystem.Text = "Hospital Mangement System";
            // 
            // lbl_PatRegNo
            // 
            this.lbl_PatRegNo.AutoSize = true;
            this.lbl_PatRegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatRegNo.Location = new System.Drawing.Point(8, 115);
            this.lbl_PatRegNo.Name = "lbl_PatRegNo";
            this.lbl_PatRegNo.Size = new System.Drawing.Size(99, 16);
            this.lbl_PatRegNo.TabIndex = 3;
            this.lbl_PatRegNo.Text = "Patient Reg No";
            // 
            // lbl_TotAmt
            // 
            this.lbl_TotAmt.AutoSize = true;
            this.lbl_TotAmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotAmt.Location = new System.Drawing.Point(7, 453);
            this.lbl_TotAmt.Name = "lbl_TotAmt";
            this.lbl_TotAmt.Size = new System.Drawing.Size(87, 16);
            this.lbl_TotAmt.TabIndex = 4;
            this.lbl_TotAmt.Text = "Total Amount";
            // 
            // lbl_PatName
            // 
            this.lbl_PatName.AutoSize = true;
            this.lbl_PatName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatName.Location = new System.Drawing.Point(7, 158);
            this.lbl_PatName.Name = "lbl_PatName";
            this.lbl_PatName.Size = new System.Drawing.Size(89, 16);
            this.lbl_PatName.TabIndex = 6;
            this.lbl_PatName.Text = "Patient Name";
            // 
            // lbl_Treatment
            // 
            this.lbl_Treatment.AutoSize = true;
            this.lbl_Treatment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Treatment.Location = new System.Drawing.Point(8, 282);
            this.lbl_Treatment.Name = "lbl_Treatment";
            this.lbl_Treatment.Size = new System.Drawing.Size(109, 16);
            this.lbl_Treatment.TabIndex = 7;
            this.lbl_Treatment.Text = "Treatment Name";
            // 
            // lbl_PayMethod
            // 
            this.lbl_PayMethod.AutoSize = true;
            this.lbl_PayMethod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PayMethod.Location = new System.Drawing.Point(7, 201);
            this.lbl_PayMethod.Name = "lbl_PayMethod";
            this.lbl_PayMethod.Size = new System.Drawing.Size(109, 16);
            this.lbl_PayMethod.TabIndex = 8;
            this.lbl_PayMethod.Text = "Payment Method";
            // 
            // lbl_CardType
            // 
            this.lbl_CardType.AutoSize = true;
            this.lbl_CardType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CardType.Location = new System.Drawing.Point(8, 243);
            this.lbl_CardType.Name = "lbl_CardType";
            this.lbl_CardType.Size = new System.Drawing.Size(72, 16);
            this.lbl_CardType.TabIndex = 10;
            this.lbl_CardType.Text = "Card Type";
            // 
            // lbl_DocFee
            // 
            this.lbl_DocFee.AutoSize = true;
            this.lbl_DocFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DocFee.Location = new System.Drawing.Point(8, 369);
            this.lbl_DocFee.Name = "lbl_DocFee";
            this.lbl_DocFee.Size = new System.Drawing.Size(75, 16);
            this.lbl_DocFee.TabIndex = 11;
            this.lbl_DocFee.Text = "Doctor Fee";
            // 
            // lbl_HosCh
            // 
            this.lbl_HosCh.AutoSize = true;
            this.lbl_HosCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HosCh.Location = new System.Drawing.Point(7, 411);
            this.lbl_HosCh.Name = "lbl_HosCh";
            this.lbl_HosCh.Size = new System.Drawing.Size(105, 16);
            this.lbl_HosCh.TabIndex = 12;
            this.lbl_HosCh.Text = "Hospital Charge";
            // 
            // lbl_TreatmentFee
            // 
            this.lbl_TreatmentFee.AutoSize = true;
            this.lbl_TreatmentFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TreatmentFee.Location = new System.Drawing.Point(7, 324);
            this.lbl_TreatmentFee.Name = "lbl_TreatmentFee";
            this.lbl_TreatmentFee.Size = new System.Drawing.Size(96, 16);
            this.lbl_TreatmentFee.TabIndex = 13;
            this.lbl_TreatmentFee.Text = "Treatment Fee";
            // 
            // txt_PatRegNo
            // 
            this.txt_PatRegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PatRegNo.Location = new System.Drawing.Point(143, 109);
            this.txt_PatRegNo.Name = "txt_PatRegNo";
            this.txt_PatRegNo.Size = new System.Drawing.Size(192, 26);
            this.txt_PatRegNo.TabIndex = 14;
            this.txt_PatRegNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_PatNme
            // 
            this.txt_PatNme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PatNme.Location = new System.Drawing.Point(143, 152);
            this.txt_PatNme.Name = "txt_PatNme";
            this.txt_PatNme.Size = new System.Drawing.Size(192, 26);
            this.txt_PatNme.TabIndex = 15;
            // 
            // txt_TreatFee
            // 
            this.txt_TreatFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TreatFee.Location = new System.Drawing.Point(144, 318);
            this.txt_TreatFee.Name = "txt_TreatFee";
            this.txt_TreatFee.Size = new System.Drawing.Size(192, 26);
            this.txt_TreatFee.TabIndex = 18;
            this.txt_TreatFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_TeatName
            // 
            this.txt_TeatName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TeatName.Location = new System.Drawing.Point(144, 276);
            this.txt_TeatName.Name = "txt_TeatName";
            this.txt_TeatName.Size = new System.Drawing.Size(192, 26);
            this.txt_TeatName.TabIndex = 19;
            // 
            // txt_Tot
            // 
            this.txt_Tot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Tot.Location = new System.Drawing.Point(144, 447);
            this.txt_Tot.Name = "txt_Tot";
            this.txt_Tot.Size = new System.Drawing.Size(192, 26);
            this.txt_Tot.TabIndex = 21;
            this.txt_Tot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_HosFee
            // 
            this.txt_HosFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_HosFee.Location = new System.Drawing.Point(144, 405);
            this.txt_HosFee.Name = "txt_HosFee";
            this.txt_HosFee.Size = new System.Drawing.Size(192, 26);
            this.txt_HosFee.TabIndex = 22;
            this.txt_HosFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_DocFee
            // 
            this.txt_DocFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DocFee.Location = new System.Drawing.Point(144, 363);
            this.txt_DocFee.Name = "txt_DocFee";
            this.txt_DocFee.Size = new System.Drawing.Size(192, 26);
            this.txt_DocFee.TabIndex = 23;
            this.txt_DocFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Menu
            // 
            this.btn_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(386, 141);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(92, 33);
            this.btn_Menu.TabIndex = 24;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = true;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(386, 405);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(92, 33);
            this.btn_Exit.TabIndex = 25;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(386, 315);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(92, 33);
            this.btn_Save.TabIndex = 27;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.Location = new System.Drawing.Point(386, 226);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(92, 33);
            this.btn_Add.TabIndex = 28;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // cmb_PayMeth
            // 
            this.cmb_PayMeth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_PayMeth.FormattingEnabled = true;
            this.cmb_PayMeth.Items.AddRange(new object[] {
            "Cash",
            "Card"});
            this.cmb_PayMeth.Location = new System.Drawing.Point(144, 195);
            this.cmb_PayMeth.Name = "cmb_PayMeth";
            this.cmb_PayMeth.Size = new System.Drawing.Size(191, 28);
            this.cmb_PayMeth.TabIndex = 29;
            // 
            // cmb_CardType
            // 
            this.cmb_CardType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CardType.FormattingEnabled = true;
            this.cmb_CardType.Items.AddRange(new object[] {
            "Credit Card",
            "Debit Card"});
            this.cmb_CardType.Location = new System.Drawing.Point(143, 237);
            this.cmb_CardType.Name = "cmb_CardType";
            this.cmb_CardType.Size = new System.Drawing.Size(192, 28);
            this.cmb_CardType.TabIndex = 30;
            // 
            // Form1_Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 492);
            this.Controls.Add(this.cmb_CardType);
            this.Controls.Add(this.cmb_PayMeth);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Menu);
            this.Controls.Add(this.txt_DocFee);
            this.Controls.Add(this.txt_HosFee);
            this.Controls.Add(this.txt_Tot);
            this.Controls.Add(this.txt_TeatName);
            this.Controls.Add(this.txt_TreatFee);
            this.Controls.Add(this.txt_PatNme);
            this.Controls.Add(this.txt_PatRegNo);
            this.Controls.Add(this.lbl_TreatmentFee);
            this.Controls.Add(this.lbl_HosCh);
            this.Controls.Add(this.lbl_DocFee);
            this.Controls.Add(this.lbl_CardType);
            this.Controls.Add(this.lbl_PayMethod);
            this.Controls.Add(this.lbl_Treatment);
            this.Controls.Add(this.lbl_PatName);
            this.Controls.Add(this.lbl_TotAmt);
            this.Controls.Add(this.lbl_PatRegNo);
            this.Controls.Add(this.panel1);
            this.Name = "Form1_Payment";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Pay;
        private System.Windows.Forms.Label lbl_HospitalMangementSystem;
        private System.Windows.Forms.Label lbl_PatRegNo;
        private System.Windows.Forms.Label lbl_TotAmt;
        private System.Windows.Forms.Label lbl_PatName;
        private System.Windows.Forms.Label lbl_Treatment;
        private System.Windows.Forms.Label lbl_PayMethod;
        private System.Windows.Forms.Label lbl_CardType;
        private System.Windows.Forms.Label lbl_DocFee;
        private System.Windows.Forms.Label lbl_HosCh;
        private System.Windows.Forms.Label lbl_TreatmentFee;
        private System.Windows.Forms.TextBox txt_PatRegNo;
        private System.Windows.Forms.TextBox txt_PatNme;
        private System.Windows.Forms.TextBox txt_TreatFee;
        private System.Windows.Forms.TextBox txt_TeatName;
        private System.Windows.Forms.TextBox txt_Tot;
        private System.Windows.Forms.TextBox txt_HosFee;
        private System.Windows.Forms.TextBox txt_DocFee;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.ComboBox cmb_PayMeth;
        private System.Windows.Forms.ComboBox cmb_CardType;
    }
}