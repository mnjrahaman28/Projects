﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1.Forms.Nurse_Link
{
    public partial class Form1_NurseLink : Form
    {
        public Form1_NurseLink()
        {
            InitializeComponent();
        }

        private void btn_Admin_Click(object sender, EventArgs e)
        {
            Form3_Administration newform = new Form3_Administration();
            newform.Show();
            this.Hide();
        }

        private void btn_Appoint_Click(object sender, EventArgs e)
        {
            Form4_Appointment newform = new Form4_Appointment();
            newform.Show();
            this.Hide();
        }

        private void btn_PatDetails_Click(object sender, EventArgs e)
        {
            Form1_PatientDetails newform = new Form1_PatientDetails();
            newform.Show();
            this.Hide();
        }

        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Form1_Payment newform = new Form1_Payment();
            newform.Show();
            this.Hide();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            DialogResult iLogin;

            iLogin = MessageBox.Show("Are you sure you want to go back to the Login System", "Hospital Management System",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            {
                Form1_Login newform = new Form1_Login();
                newform.Show();
                this.Hide();
            }

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
