﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Forms.Nurse_Link;
using System.Data.OleDb;

namespace WindowsFormsApplication1.Forms
{
    public partial class Form1_Payment : Form
    {
        int a, b, c, d;
        public Form1_Payment()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Naveed Rahaman\Desktop\New Lanka_Final Pro\WindowsFormsApplication1\New Lanka Hospital_23.mdb");
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            Form1_NurseLink newform = new Form1_NurseLink();
            newform.Show();
            this.Hide();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into Payment(PatientReg_No,Patient_Name,Payment_Meth,Card_Type,Treat_Name,Treat_Fee,Doc_Fee,Hospital_Fee,Total_Amt)values('" + txt_PatRegNo.Text + "','" + txt_PatNme.Text + "','" + cmb_PayMeth.Text + "','" + cmb_CardType.Text + "','" + txt_TeatName.Text + "','" + txt_TreatFee.Text + "','" + txt_DocFee.Text + "','" + txt_HosFee.Text + "','" + txt_Tot.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Save Successfully");
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txt_TreatFee.Text);
            b = Convert.ToInt32(txt_DocFee.Text);
            c = Convert.ToInt32(txt_HosFee.Text);
            d = a + b + c;
            txt_Tot.Text = d.ToString();
        }
    }
}
