﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Forms.Nurse_Link;
using System.Data.OleDb;

namespace WindowsFormsApplication1.Forms
{
    public partial class Form1_PatientDetails : Form
    {
        public Form1_PatientDetails()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Naveed Rahaman\Desktop\New Lanka_Final Pro\WindowsFormsApplication1\New Lanka Hospital_23.mdb");
        private void btn_Menu_Click(object sender, EventArgs e)
        {
            Form1_NurseLink newform = new Form1_NurseLink();
            newform.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into PatientDetails(Name,DOB,Gender,Occupation,Phone,Registration_Number,Patient_Address,ICE_Name,ICE_Phone,ICE_Relationship,ICE_Address,AddmitedDate,Last_Visit,Custormer_Type,Payment_Plan)values('" + txt_PDName.Text + "','" + dtp_DOB.Text + "','" + cmb_Gen.Text + "','" + txt_ocu.Text + "','" + txt_PDMob.Text + "','" + txt_RegNo.Text + "','" + txt_PatAddress.Text + "','" + txt_ICENme.Text + "','" + txt_ICEMob.Text + "','" + cmb_Relation.Text + "','" + txt_ICEAddress.Text + "','" + dtp_Addmit.Text + "','" + dtp_LVisit.Text + "','" + cmb_CusType.Text + "','" + cmb_PayPlan.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Save Successfully");
        }
    }
}
