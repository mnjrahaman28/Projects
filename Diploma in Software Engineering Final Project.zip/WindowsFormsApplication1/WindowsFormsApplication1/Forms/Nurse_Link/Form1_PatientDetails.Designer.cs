﻿namespace WindowsFormsApplication1.Forms
{
    partial class Form1_PatientDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.txt_PatAddress = new System.Windows.Forms.TextBox();
            this.txt_RegNo = new System.Windows.Forms.TextBox();
            this.cmb_MatStatus = new System.Windows.Forms.ComboBox();
            this.lbl_MStatus = new System.Windows.Forms.Label();
            this.txt_PDMob = new System.Windows.Forms.TextBox();
            this.lbl_PMob = new System.Windows.Forms.Label();
            this.lbl_occupation = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.txt_ocu = new System.Windows.Forms.TextBox();
            this.cmb_Gen = new System.Windows.Forms.ComboBox();
            this.lbl_PReg = new System.Windows.Forms.Label();
            this.txt_PDName = new System.Windows.Forms.TextBox();
            this.lbl_PName = new System.Windows.Forms.Label();
            this.lbl_PDOB = new System.Windows.Forms.Label();
            this.lbl_PAddress = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_ICEAddress = new System.Windows.Forms.TextBox();
            this.lbl_relation = new System.Windows.Forms.Label();
            this.cmb_Relation = new System.Windows.Forms.ComboBox();
            this.txt_ICEMob = new System.Windows.Forms.TextBox();
            this.txt_ICENme = new System.Windows.Forms.TextBox();
            this.lbl_ICEName = new System.Windows.Forms.Label();
            this.lbl_ICEAddress = new System.Windows.Forms.Label();
            this.lbl_ICEPhone = new System.Windows.Forms.Label();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtp_LVisit = new System.Windows.Forms.DateTimePicker();
            this.dtp_Addmit = new System.Windows.Forms.DateTimePicker();
            this.cmb_PayPlan = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_AddmitDate = new System.Windows.Forms.Label();
            this.cmb_CusType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_LVisit = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtp_DOB);
            this.groupBox1.Controls.Add(this.txt_PatAddress);
            this.groupBox1.Controls.Add(this.txt_RegNo);
            this.groupBox1.Controls.Add(this.cmb_MatStatus);
            this.groupBox1.Controls.Add(this.lbl_MStatus);
            this.groupBox1.Controls.Add(this.txt_PDMob);
            this.groupBox1.Controls.Add(this.lbl_PMob);
            this.groupBox1.Controls.Add(this.lbl_occupation);
            this.groupBox1.Controls.Add(this.lbl_Gender);
            this.groupBox1.Controls.Add(this.txt_ocu);
            this.groupBox1.Controls.Add(this.cmb_Gen);
            this.groupBox1.Controls.Add(this.lbl_PReg);
            this.groupBox1.Controls.Add(this.txt_PDName);
            this.groupBox1.Controls.Add(this.lbl_PName);
            this.groupBox1.Controls.Add(this.lbl_PDOB);
            this.groupBox1.Controls.Add(this.lbl_PAddress);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(441, 466);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Patient Details";
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.CustomFormat = "";
            this.dtp_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_DOB.Location = new System.Drawing.Point(172, 81);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtp_DOB.Size = new System.Drawing.Size(227, 26);
            this.dtp_DOB.TabIndex = 31;
            this.dtp_DOB.Value = new System.DateTime(2020, 2, 15, 12, 0, 0, 0);
            // 
            // txt_PatAddress
            // 
            this.txt_PatAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PatAddress.Location = new System.Drawing.Point(172, 357);
            this.txt_PatAddress.Name = "txt_PatAddress";
            this.txt_PatAddress.Size = new System.Drawing.Size(228, 26);
            this.txt_PatAddress.TabIndex = 30;
            // 
            // txt_RegNo
            // 
            this.txt_RegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_RegNo.Location = new System.Drawing.Point(172, 307);
            this.txt_RegNo.Name = "txt_RegNo";
            this.txt_RegNo.Size = new System.Drawing.Size(228, 26);
            this.txt_RegNo.TabIndex = 27;
            this.txt_RegNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmb_MatStatus
            // 
            this.cmb_MatStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_MatStatus.FormattingEnabled = true;
            this.cmb_MatStatus.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.cmb_MatStatus.Location = new System.Drawing.Point(172, 414);
            this.cmb_MatStatus.Name = "cmb_MatStatus";
            this.cmb_MatStatus.Size = new System.Drawing.Size(228, 28);
            this.cmb_MatStatus.TabIndex = 26;
            // 
            // lbl_MStatus
            // 
            this.lbl_MStatus.AutoSize = true;
            this.lbl_MStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MStatus.Location = new System.Drawing.Point(6, 420);
            this.lbl_MStatus.Name = "lbl_MStatus";
            this.lbl_MStatus.Size = new System.Drawing.Size(88, 16);
            this.lbl_MStatus.TabIndex = 24;
            this.lbl_MStatus.Text = "Marital Status";
            // 
            // txt_PDMob
            // 
            this.txt_PDMob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDMob.Location = new System.Drawing.Point(172, 253);
            this.txt_PDMob.Multiline = true;
            this.txt_PDMob.Name = "txt_PDMob";
            this.txt_PDMob.Size = new System.Drawing.Size(228, 26);
            this.txt_PDMob.TabIndex = 18;
            this.txt_PDMob.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_PMob
            // 
            this.lbl_PMob.AutoSize = true;
            this.lbl_PMob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PMob.Location = new System.Drawing.Point(6, 259);
            this.lbl_PMob.Name = "lbl_PMob";
            this.lbl_PMob.Size = new System.Drawing.Size(47, 16);
            this.lbl_PMob.TabIndex = 6;
            this.lbl_PMob.Text = "Phone";
            // 
            // lbl_occupation
            // 
            this.lbl_occupation.AutoSize = true;
            this.lbl_occupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_occupation.Location = new System.Drawing.Point(6, 209);
            this.lbl_occupation.Name = "lbl_occupation";
            this.lbl_occupation.Size = new System.Drawing.Size(76, 16);
            this.lbl_occupation.TabIndex = 20;
            this.lbl_occupation.Text = "Occupation";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(6, 145);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(53, 16);
            this.lbl_Gender.TabIndex = 18;
            this.lbl_Gender.Text = "Gender";
            // 
            // txt_ocu
            // 
            this.txt_ocu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ocu.Location = new System.Drawing.Point(172, 203);
            this.txt_ocu.Name = "txt_ocu";
            this.txt_ocu.Size = new System.Drawing.Size(228, 26);
            this.txt_ocu.TabIndex = 15;
            // 
            // cmb_Gen
            // 
            this.cmb_Gen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Gen.FormattingEnabled = true;
            this.cmb_Gen.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmb_Gen.Location = new System.Drawing.Point(171, 139);
            this.cmb_Gen.Name = "cmb_Gen";
            this.cmb_Gen.Size = new System.Drawing.Size(229, 28);
            this.cmb_Gen.TabIndex = 19;
            // 
            // lbl_PReg
            // 
            this.lbl_PReg.AutoSize = true;
            this.lbl_PReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PReg.Location = new System.Drawing.Point(6, 313);
            this.lbl_PReg.Name = "lbl_PReg";
            this.lbl_PReg.Size = new System.Drawing.Size(131, 16);
            this.lbl_PReg.TabIndex = 14;
            this.lbl_PReg.Text = "Registration Number";
            // 
            // txt_PDName
            // 
            this.txt_PDName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDName.Location = new System.Drawing.Point(170, 36);
            this.txt_PDName.Name = "txt_PDName";
            this.txt_PDName.Size = new System.Drawing.Size(229, 26);
            this.txt_PDName.TabIndex = 10;
            // 
            // lbl_PName
            // 
            this.lbl_PName.AutoSize = true;
            this.lbl_PName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PName.Location = new System.Drawing.Point(6, 40);
            this.lbl_PName.Name = "lbl_PName";
            this.lbl_PName.Size = new System.Drawing.Size(45, 16);
            this.lbl_PName.TabIndex = 3;
            this.lbl_PName.Text = "Name";
            // 
            // lbl_PDOB
            // 
            this.lbl_PDOB.AutoSize = true;
            this.lbl_PDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PDOB.Location = new System.Drawing.Point(6, 85);
            this.lbl_PDOB.Name = "lbl_PDOB";
            this.lbl_PDOB.Size = new System.Drawing.Size(117, 16);
            this.lbl_PDOB.TabIndex = 4;
            this.lbl_PDOB.Text = "Date of Birth(DOB)";
            // 
            // lbl_PAddress
            // 
            this.lbl_PAddress.AutoSize = true;
            this.lbl_PAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PAddress.Location = new System.Drawing.Point(6, 363);
            this.lbl_PAddress.Name = "lbl_PAddress";
            this.lbl_PAddress.Size = new System.Drawing.Size(103, 16);
            this.lbl_PAddress.TabIndex = 8;
            this.lbl_PAddress.Text = "Patient Address";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 105);
            this.panel1.TabIndex = 12;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(320, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(237, 37);
            this.label3.TabIndex = 1;
            this.label3.Text = "Patient Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(154, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(519, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital Mangement System";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txt_ICEAddress);
            this.groupBox3.Controls.Add(this.lbl_relation);
            this.groupBox3.Controls.Add(this.cmb_Relation);
            this.groupBox3.Controls.Add(this.txt_ICEMob);
            this.groupBox3.Controls.Add(this.txt_ICENme);
            this.groupBox3.Controls.Add(this.lbl_ICEName);
            this.groupBox3.Controls.Add(this.lbl_ICEAddress);
            this.groupBox3.Controls.Add(this.lbl_ICEPhone);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(445, 109);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(402, 210);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "In case of Emerncy";
            // 
            // txt_ICEAddress
            // 
            this.txt_ICEAddress.Location = new System.Drawing.Point(141, 159);
            this.txt_ICEAddress.Name = "txt_ICEAddress";
            this.txt_ICEAddress.Size = new System.Drawing.Size(234, 26);
            this.txt_ICEAddress.TabIndex = 18;
            // 
            // lbl_relation
            // 
            this.lbl_relation.AutoSize = true;
            this.lbl_relation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_relation.Location = new System.Drawing.Point(6, 116);
            this.lbl_relation.Name = "lbl_relation";
            this.lbl_relation.Size = new System.Drawing.Size(58, 16);
            this.lbl_relation.TabIndex = 17;
            this.lbl_relation.Text = "Relation";
            // 
            // cmb_Relation
            // 
            this.cmb_Relation.FormattingEnabled = true;
            this.cmb_Relation.Items.AddRange(new object[] {
            "Partner",
            "Husband",
            "Wife",
            "Child",
            "Son",
            "Daughter",
            "Father",
            "Mother",
            "Brother",
            "Sister",
            "Grand Mother",
            "Grand Father",
            "Relative",
            "Aunt",
            "Uncle",
            "Friend",
            "Assistant"});
            this.cmb_Relation.Location = new System.Drawing.Point(140, 116);
            this.cmb_Relation.Name = "cmb_Relation";
            this.cmb_Relation.Size = new System.Drawing.Size(235, 28);
            this.cmb_Relation.TabIndex = 16;
            // 
            // txt_ICEMob
            // 
            this.txt_ICEMob.Location = new System.Drawing.Point(141, 76);
            this.txt_ICEMob.Name = "txt_ICEMob";
            this.txt_ICEMob.Size = new System.Drawing.Size(234, 26);
            this.txt_ICEMob.TabIndex = 11;
            this.txt_ICEMob.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ICENme
            // 
            this.txt_ICENme.Location = new System.Drawing.Point(140, 37);
            this.txt_ICENme.Name = "txt_ICENme";
            this.txt_ICENme.Size = new System.Drawing.Size(235, 26);
            this.txt_ICENme.TabIndex = 10;
            // 
            // lbl_ICEName
            // 
            this.lbl_ICEName.AutoSize = true;
            this.lbl_ICEName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICEName.Location = new System.Drawing.Point(6, 37);
            this.lbl_ICEName.Name = "lbl_ICEName";
            this.lbl_ICEName.Size = new System.Drawing.Size(45, 16);
            this.lbl_ICEName.TabIndex = 4;
            this.lbl_ICEName.Text = "Name";
            // 
            // lbl_ICEAddress
            // 
            this.lbl_ICEAddress.AutoSize = true;
            this.lbl_ICEAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICEAddress.Location = new System.Drawing.Point(7, 159);
            this.lbl_ICEAddress.Name = "lbl_ICEAddress";
            this.lbl_ICEAddress.Size = new System.Drawing.Size(59, 16);
            this.lbl_ICEAddress.TabIndex = 8;
            this.lbl_ICEAddress.Text = "Address";
            // 
            // lbl_ICEPhone
            // 
            this.lbl_ICEPhone.AutoSize = true;
            this.lbl_ICEPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ICEPhone.Location = new System.Drawing.Point(6, 76);
            this.lbl_ICEPhone.Name = "lbl_ICEPhone";
            this.lbl_ICEPhone.Size = new System.Drawing.Size(47, 16);
            this.lbl_ICEPhone.TabIndex = 6;
            this.lbl_ICEPhone.Text = "Phone";
            // 
            // btn_Menu
            // 
            this.btn_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(460, 535);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(84, 39);
            this.btn_Menu.TabIndex = 2;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = true;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(742, 535);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(84, 39);
            this.btn_Exit.TabIndex = 21;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtp_LVisit);
            this.groupBox2.Controls.Add(this.dtp_Addmit);
            this.groupBox2.Controls.Add(this.cmb_PayPlan);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lbl_AddmitDate);
            this.groupBox2.Controls.Add(this.cmb_CusType);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lbl_LVisit);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(445, 322);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(401, 207);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "For Hospital Use Only";
            // 
            // dtp_LVisit
            // 
            this.dtp_LVisit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_LVisit.Location = new System.Drawing.Point(140, 69);
            this.dtp_LVisit.Name = "dtp_LVisit";
            this.dtp_LVisit.Size = new System.Drawing.Size(223, 26);
            this.dtp_LVisit.TabIndex = 10;
            // 
            // dtp_Addmit
            // 
            this.dtp_Addmit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Addmit.Location = new System.Drawing.Point(139, 31);
            this.dtp_Addmit.Name = "dtp_Addmit";
            this.dtp_Addmit.Size = new System.Drawing.Size(218, 26);
            this.dtp_Addmit.TabIndex = 9;
            this.dtp_Addmit.Value = new System.DateTime(2020, 2, 15, 11, 23, 53, 0);
            // 
            // cmb_PayPlan
            // 
            this.cmb_PayPlan.FormattingEnabled = true;
            this.cmb_PayPlan.Items.AddRange(new object[] {
            "Daily",
            "Monthly"});
            this.cmb_PayPlan.Location = new System.Drawing.Point(140, 161);
            this.cmb_PayPlan.Name = "cmb_PayPlan";
            this.cmb_PayPlan.Size = new System.Drawing.Size(234, 28);
            this.cmb_PayPlan.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Payment Plan";
            // 
            // lbl_AddmitDate
            // 
            this.lbl_AddmitDate.AutoSize = true;
            this.lbl_AddmitDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AddmitDate.Location = new System.Drawing.Point(6, 39);
            this.lbl_AddmitDate.Name = "lbl_AddmitDate";
            this.lbl_AddmitDate.Size = new System.Drawing.Size(98, 16);
            this.lbl_AddmitDate.TabIndex = 5;
            this.lbl_AddmitDate.Text = "Addmited Date";
            // 
            // cmb_CusType
            // 
            this.cmb_CusType.FormattingEnabled = true;
            this.cmb_CusType.Items.AddRange(new object[] {
            "Regular Customer",
            "New Customer"});
            this.cmb_CusType.Location = new System.Drawing.Point(139, 117);
            this.cmb_CusType.Name = "cmb_CusType";
            this.cmb_CusType.Size = new System.Drawing.Size(234, 28);
            this.cmb_CusType.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Customer Type";
            // 
            // lbl_LVisit
            // 
            this.lbl_LVisit.AutoSize = true;
            this.lbl_LVisit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LVisit.Location = new System.Drawing.Point(6, 77);
            this.lbl_LVisit.Name = "lbl_LVisit";
            this.lbl_LVisit.Size = new System.Drawing.Size(61, 16);
            this.lbl_LVisit.TabIndex = 0;
            this.lbl_LVisit.Text = "Last Visit";
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(620, 535);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(83, 39);
            this.btn_Save.TabIndex = 23;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // Form1_PatientDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 581);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Menu);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1_PatientDetails";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_ocu;
        private System.Windows.Forms.Label lbl_PReg;
        private System.Windows.Forms.TextBox txt_PDName;
        private System.Windows.Forms.Label lbl_PName;
        private System.Windows.Forms.Label lbl_PDOB;
        private System.Windows.Forms.Label lbl_PAddress;
        private System.Windows.Forms.Label lbl_PMob;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmb_Relation;
        private System.Windows.Forms.TextBox txt_ICEMob;
        private System.Windows.Forms.TextBox txt_ICENme;
        private System.Windows.Forms.Label lbl_ICEName;
        private System.Windows.Forms.Label lbl_ICEAddress;
        private System.Windows.Forms.Label lbl_ICEPhone;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.ComboBox cmb_Gen;
        private System.Windows.Forms.Label lbl_relation;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Label lbl_occupation;
        private System.Windows.Forms.TextBox txt_PDMob;
        private System.Windows.Forms.TextBox txt_RegNo;
        private System.Windows.Forms.ComboBox cmb_MatStatus;
        private System.Windows.Forms.Label lbl_MStatus;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmb_CusType;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_LVisit;
        private System.Windows.Forms.Label lbl_AddmitDate;
        private System.Windows.Forms.ComboBox cmb_PayPlan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_PatAddress;
        private System.Windows.Forms.TextBox txt_ICEAddress;
        private System.Windows.Forms.DateTimePicker dtp_LVisit;
        private System.Windows.Forms.DateTimePicker dtp_Addmit;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
    }
}