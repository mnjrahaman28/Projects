﻿namespace WindowsFormsApplication1.Forms.Nurse_Link
{
    partial class Form1_NurseLink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_Payment = new System.Windows.Forms.Button();
            this.btn_Admin = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_HospitalMangementSystem = new System.Windows.Forms.Label();
            this.btn_Appoint = new System.Windows.Forms.Button();
            this.btn_PatDetails = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(429, 190);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(81, 35);
            this.btn_Exit.TabIndex = 11;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Login.Location = new System.Drawing.Point(329, 190);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(81, 35);
            this.btn_Login.TabIndex = 10;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_Payment
            // 
            this.btn_Payment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Payment.Location = new System.Drawing.Point(374, 131);
            this.btn_Payment.Name = "btn_Payment";
            this.btn_Payment.Size = new System.Drawing.Size(136, 33);
            this.btn_Payment.TabIndex = 9;
            this.btn_Payment.Text = "Payment";
            this.btn_Payment.UseVisualStyleBackColor = true;
            this.btn_Payment.Click += new System.EventHandler(this.btn_Payment_Click);
            // 
            // btn_Admin
            // 
            this.btn_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Admin.Location = new System.Drawing.Point(210, 75);
            this.btn_Admin.Name = "btn_Admin";
            this.btn_Admin.Size = new System.Drawing.Size(136, 33);
            this.btn_Admin.TabIndex = 8;
            this.btn_Admin.Text = "Administration";
            this.btn_Admin.UseVisualStyleBackColor = true;
            this.btn_Admin.Click += new System.EventHandler(this.btn_Admin_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_HospitalMangementSystem);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(611, 68);
            this.panel1.TabIndex = 12;
            // 
            // lbl_HospitalMangementSystem
            // 
            this.lbl_HospitalMangementSystem.AutoSize = true;
            this.lbl_HospitalMangementSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalMangementSystem.Location = new System.Drawing.Point(6, 11);
            this.lbl_HospitalMangementSystem.Name = "lbl_HospitalMangementSystem";
            this.lbl_HospitalMangementSystem.Size = new System.Drawing.Size(519, 42);
            this.lbl_HospitalMangementSystem.TabIndex = 0;
            this.lbl_HospitalMangementSystem.Text = "Hospital Mangement System";
            // 
            // btn_Appoint
            // 
            this.btn_Appoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Appoint.Location = new System.Drawing.Point(374, 75);
            this.btn_Appoint.Name = "btn_Appoint";
            this.btn_Appoint.Size = new System.Drawing.Size(136, 33);
            this.btn_Appoint.TabIndex = 13;
            this.btn_Appoint.Text = "Appointment";
            this.btn_Appoint.UseVisualStyleBackColor = true;
            this.btn_Appoint.Click += new System.EventHandler(this.btn_Appoint_Click);
            // 
            // btn_PatDetails
            // 
            this.btn_PatDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PatDetails.Location = new System.Drawing.Point(210, 131);
            this.btn_PatDetails.Name = "btn_PatDetails";
            this.btn_PatDetails.Size = new System.Drawing.Size(136, 33);
            this.btn_PatDetails.TabIndex = 14;
            this.btn_PatDetails.Text = "Patient Details";
            this.btn_PatDetails.UseVisualStyleBackColor = true;
            this.btn_PatDetails.Click += new System.EventHandler(this.btn_PatDetails_Click);
            // 
            // Form1_NurseLink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 249);
            this.Controls.Add(this.btn_PatDetails);
            this.Controls.Add(this.btn_Appoint);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.btn_Payment);
            this.Controls.Add(this.btn_Admin);
            this.Name = "Form1_NurseLink";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_Payment;
        private System.Windows.Forms.Button btn_Admin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_HospitalMangementSystem;
        private System.Windows.Forms.Button btn_Appoint;
        private System.Windows.Forms.Button btn_PatDetails;
    }
}