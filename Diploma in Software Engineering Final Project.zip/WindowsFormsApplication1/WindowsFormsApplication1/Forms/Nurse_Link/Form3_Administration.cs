﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using WindowsFormsApplication1.Forms.Nurse_Link;
using WindowsFormsApplication1.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3_Administration : Form
    {
        public Form3_Administration()
        {
            InitializeComponent();
        }

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Naveed Rahaman\Desktop\New Lanka_Final Pro\WindowsFormsApplication1\New Lanka Hospital_23.mdb");

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            Form1_NurseLink newform = new Form1_NurseLink();
            newform.Show();
            this.Hide();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Form3_Admin_Load(object sender, EventArgs e)
        {

        }
    
        private void btn_SaveT_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into Administration(Doctor_ID,Nurse_ID,Duty_Shift,Ward)values('" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + comboBox4.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Save Successfully");
        }

    }
}
