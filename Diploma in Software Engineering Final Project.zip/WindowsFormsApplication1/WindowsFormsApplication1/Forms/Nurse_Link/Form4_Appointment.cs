﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using WindowsFormsApplication1.Forms;
using WindowsFormsApplication1.Forms.Nurse_Link;

namespace WindowsFormsApplication1
{
    public partial class Form4_Appointment : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public Form4_Appointment()
        {
            InitializeComponent();
        }    
        
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Naveed Rahaman\Desktop\New Lanka_Final Pro\WindowsFormsApplication1\New Lanka Hospital_23.mdb");

        private void btn_Save_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into Appointment(PatientReg_No,Appointment_ID,Appointment_Date,Appointment_Time,Doctor_ID)values('" + txt_PatRegNo.Text + "','" + txt_AppointmentID.Text + "','" + dtp_ApointDate.Text + "','" + dtp_ApointTme.Text + "','" + comboBox1_DocID.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Save Successfully");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
               {
                    Application.Exit();
                }
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            Form1_NurseLink newform = new Form1_NurseLink();
            newform.Show();
            this.Hide();
        }

        private void Form4_Appointment_Load(object sender, EventArgs e)
        {
            
        }

        private void dtp_ApointDate_ValueChanged(object sender, EventArgs e)
        {
            
        }
    }
}
