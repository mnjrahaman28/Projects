﻿namespace WindowsFormsApplication1
{
    partial class Form3_Administration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Administration = new System.Windows.Forms.Label();
            this.lbl_HospitalMangementSystem = new System.Windows.Forms.Label();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_NurseID = new System.Windows.Forms.Label();
            this.lbl_DutyShift = new System.Windows.Forms.Label();
            this.lbl_DocID = new System.Windows.Forms.Label();
            this.lbl_Ward = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btn_SaveT = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Administration);
            this.panel1.Controls.Add(this.lbl_HospitalMangementSystem);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(491, 75);
            this.panel1.TabIndex = 1;
            // 
            // lbl_Administration
            // 
            this.lbl_Administration.AutoSize = true;
            this.lbl_Administration.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Administration.Location = new System.Drawing.Point(129, 39);
            this.lbl_Administration.Name = "lbl_Administration";
            this.lbl_Administration.Size = new System.Drawing.Size(200, 31);
            this.lbl_Administration.TabIndex = 1;
            this.lbl_Administration.Text = "Administration";
            // 
            // lbl_HospitalMangementSystem
            // 
            this.lbl_HospitalMangementSystem.AutoSize = true;
            this.lbl_HospitalMangementSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HospitalMangementSystem.Location = new System.Drawing.Point(1, 0);
            this.lbl_HospitalMangementSystem.Name = "lbl_HospitalMangementSystem";
            this.lbl_HospitalMangementSystem.Size = new System.Drawing.Size(487, 39);
            this.lbl_HospitalMangementSystem.TabIndex = 0;
            this.lbl_HospitalMangementSystem.Text = "Hospital Mangement System";
            // 
            // btn_Menu
            // 
            this.btn_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(383, 107);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(78, 37);
            this.btn_Menu.TabIndex = 3;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = true;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(383, 242);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(78, 37);
            this.btn_Exit.TabIndex = 4;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // lbl_NurseID
            // 
            this.lbl_NurseID.AutoSize = true;
            this.lbl_NurseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NurseID.Location = new System.Drawing.Point(5, 154);
            this.lbl_NurseID.Name = "lbl_NurseID";
            this.lbl_NurseID.Size = new System.Drawing.Size(60, 16);
            this.lbl_NurseID.TabIndex = 2;
            this.lbl_NurseID.Text = "Nurse ID";
            // 
            // lbl_DutyShift
            // 
            this.lbl_DutyShift.AutoSize = true;
            this.lbl_DutyShift.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DutyShift.Location = new System.Drawing.Point(5, 219);
            this.lbl_DutyShift.Name = "lbl_DutyShift";
            this.lbl_DutyShift.Size = new System.Drawing.Size(63, 16);
            this.lbl_DutyShift.TabIndex = 3;
            this.lbl_DutyShift.Text = "Duty Shift";
            // 
            // lbl_DocID
            // 
            this.lbl_DocID.AutoSize = true;
            this.lbl_DocID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DocID.Location = new System.Drawing.Point(5, 96);
            this.lbl_DocID.Name = "lbl_DocID";
            this.lbl_DocID.Size = new System.Drawing.Size(64, 16);
            this.lbl_DocID.TabIndex = 4;
            this.lbl_DocID.Text = "Doctor ID";
            // 
            // lbl_Ward
            // 
            this.lbl_Ward.AutoSize = true;
            this.lbl_Ward.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ward.Location = new System.Drawing.Point(5, 289);
            this.lbl_Ward.Name = "lbl_Ward";
            this.lbl_Ward.Size = new System.Drawing.Size(41, 16);
            this.lbl_Ward.TabIndex = 5;
            this.lbl_Ward.Text = "Ward";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Doc_101",
            "Doc_102",
            "Doc_103",
            "Doc_104",
            "Doc_105"});
            this.comboBox1.Location = new System.Drawing.Point(135, 90);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(194, 28);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.Text = "Doc ID";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Day",
            "Night"});
            this.comboBox3.Location = new System.Drawing.Point(135, 213);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(194, 28);
            this.comboBox3.TabIndex = 8;
            this.comboBox3.Text = "Duty Shift";
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Ward No - 1",
            "Ward No - 2",
            "Ward No - 3",
            "Ward No - 4",
            "Ward No - 5",
            "Ward No - 6",
            "Ward No - 7",
            "Ward No - 8"});
            this.comboBox4.Location = new System.Drawing.Point(135, 283);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(196, 28);
            this.comboBox4.TabIndex = 9;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Nurse_201",
            "Nurse_202",
            "Nurse_203",
            "Nurse_204",
            "Nurse_205"});
            this.comboBox2.Location = new System.Drawing.Point(135, 148);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(194, 28);
            this.comboBox2.TabIndex = 11;
            this.comboBox2.Text = "Nurse ID";
            // 
            // btn_SaveT
            // 
            this.btn_SaveT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SaveT.Location = new System.Drawing.Point(383, 172);
            this.btn_SaveT.Name = "btn_SaveT";
            this.btn_SaveT.Size = new System.Drawing.Size(78, 37);
            this.btn_SaveT.TabIndex = 12;
            this.btn_SaveT.Text = "Save";
            this.btn_SaveT.UseVisualStyleBackColor = true;
            this.btn_SaveT.Click += new System.EventHandler(this.btn_SaveT_Click);
            // 
            // Form3_Administration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(485, 328);
            this.Controls.Add(this.btn_SaveT);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lbl_Ward);
            this.Controls.Add(this.lbl_NurseID);
            this.Controls.Add(this.lbl_DocID);
            this.Controls.Add(this.btn_Menu);
            this.Controls.Add(this.lbl_DutyShift);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.panel1);
            this.Name = "Form3_Administration";
            this.Load += new System.EventHandler(this.Form3_Admin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Administration;
        private System.Windows.Forms.Label lbl_HospitalMangementSystem;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_NurseID;
        private System.Windows.Forms.Label lbl_DutyShift;
        private System.Windows.Forms.Label lbl_DocID;
        private System.Windows.Forms.Label lbl_Ward;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button btn_SaveT;
    }
}