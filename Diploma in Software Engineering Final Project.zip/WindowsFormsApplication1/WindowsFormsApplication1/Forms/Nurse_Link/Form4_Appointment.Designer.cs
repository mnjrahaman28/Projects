﻿namespace WindowsFormsApplication1
{
    partial class Form4_Appointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_AppointmentID = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_AppointmentID = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_PatRegNo = new System.Windows.Forms.Label();
            this.txt_PatRegNo = new System.Windows.Forms.TextBox();
            this.lbl_DocID = new System.Windows.Forms.Label();
            this.comboBox1_DocID = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtp_ApointTme = new System.Windows.Forms.DateTimePicker();
            this.dtp_ApointDate = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(554, 84);
            this.panel1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(161, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 33);
            this.label3.TabIndex = 1;
            this.label3.Text = "Appointment";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(487, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital Mangement System";
            // 
            // lbl_AppointmentID
            // 
            this.lbl_AppointmentID.AutoSize = true;
            this.lbl_AppointmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AppointmentID.Location = new System.Drawing.Point(10, 155);
            this.lbl_AppointmentID.Name = "lbl_AppointmentID";
            this.lbl_AppointmentID.Size = new System.Drawing.Size(96, 16);
            this.lbl_AppointmentID.TabIndex = 5;
            this.lbl_AppointmentID.Text = "Appoinment ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "Appointment Date";
            // 
            // txt_AppointmentID
            // 
            this.txt_AppointmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AppointmentID.Location = new System.Drawing.Point(167, 143);
            this.txt_AppointmentID.Name = "txt_AppointmentID";
            this.txt_AppointmentID.Size = new System.Drawing.Size(286, 26);
            this.txt_AppointmentID.TabIndex = 17;
            this.txt_AppointmentID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(198, 373);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 32);
            this.btn_Save.TabIndex = 16;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Menu
            // 
            this.btn_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(31, 373);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(75, 32);
            this.btn_Menu.TabIndex = 17;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = true;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(349, 373);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 32);
            this.btn_Exit.TabIndex = 18;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.button3_Click);
            // 
            // lbl_PatRegNo
            // 
            this.lbl_PatRegNo.AutoSize = true;
            this.lbl_PatRegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PatRegNo.Location = new System.Drawing.Point(10, 110);
            this.lbl_PatRegNo.Name = "lbl_PatRegNo";
            this.lbl_PatRegNo.Size = new System.Drawing.Size(145, 16);
            this.lbl_PatRegNo.TabIndex = 18;
            this.lbl_PatRegNo.Text = "Patient Registration No";
            // 
            // txt_PatRegNo
            // 
            this.txt_PatRegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PatRegNo.Location = new System.Drawing.Point(167, 98);
            this.txt_PatRegNo.Name = "txt_PatRegNo";
            this.txt_PatRegNo.Size = new System.Drawing.Size(286, 26);
            this.txt_PatRegNo.TabIndex = 19;
            this.txt_PatRegNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_DocID
            // 
            this.lbl_DocID.AutoSize = true;
            this.lbl_DocID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DocID.Location = new System.Drawing.Point(10, 320);
            this.lbl_DocID.Name = "lbl_DocID";
            this.lbl_DocID.Size = new System.Drawing.Size(64, 16);
            this.lbl_DocID.TabIndex = 21;
            this.lbl_DocID.Text = "Doctor ID";
            // 
            // comboBox1_DocID
            // 
            this.comboBox1_DocID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1_DocID.FormattingEnabled = true;
            this.comboBox1_DocID.Items.AddRange(new object[] {
            "Doc_01",
            "Doc_02",
            "Doc_03",
            "Doc_04",
            "Doc_05"});
            this.comboBox1_DocID.Location = new System.Drawing.Point(167, 308);
            this.comboBox1_DocID.Name = "comboBox1_DocID";
            this.comboBox1_DocID.Size = new System.Drawing.Size(286, 28);
            this.comboBox1_DocID.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "Appointment Time";
            // 
            // dtp_ApointTme
            // 
            this.dtp_ApointTme.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ApointTme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ApointTme.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_ApointTme.Location = new System.Drawing.Point(167, 250);
            this.dtp_ApointTme.MaxDate = new System.DateTime(5500, 12, 31, 0, 0, 0, 0);
            this.dtp_ApointTme.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.dtp_ApointTme.Name = "dtp_ApointTme";
            this.dtp_ApointTme.Size = new System.Drawing.Size(286, 26);
            this.dtp_ApointTme.TabIndex = 26;
            this.dtp_ApointTme.Value = new System.DateTime(2020, 2, 16, 0, 0, 0, 0);
            // 
            // dtp_ApointDate
            // 
            this.dtp_ApointDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ApointDate.CustomFormat = "";
            this.dtp_ApointDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ApointDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_ApointDate.Location = new System.Drawing.Point(167, 194);
            this.dtp_ApointDate.Name = "dtp_ApointDate";
            this.dtp_ApointDate.Size = new System.Drawing.Size(286, 26);
            this.dtp_ApointDate.TabIndex = 27;
            this.dtp_ApointDate.Value = new System.DateTime(2020, 2, 16, 19, 14, 44, 0);
            this.dtp_ApointDate.ValueChanged += new System.EventHandler(this.dtp_ApointDate_ValueChanged);
            // 
            // Form4_Appointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 424);
            this.Controls.Add(this.dtp_ApointDate);
            this.Controls.Add(this.dtp_ApointTme);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1_DocID);
            this.Controls.Add(this.lbl_DocID);
            this.Controls.Add(this.txt_PatRegNo);
            this.Controls.Add(this.btn_Menu);
            this.Controls.Add(this.lbl_PatRegNo);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.txt_AppointmentID);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbl_AppointmentID);
            this.Controls.Add(this.label9);
            this.Name = "Form4_Appointment";
            this.Load += new System.EventHandler(this.Form4_Appointment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_AppointmentID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_AppointmentID;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.TextBox txt_PatRegNo;
        private System.Windows.Forms.Label lbl_PatRegNo;
        private System.Windows.Forms.Label lbl_DocID;
        private System.Windows.Forms.ComboBox comboBox1_DocID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtp_ApointTme;
        private System.Windows.Forms.DateTimePicker dtp_ApointDate;
    }
}