﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using WindowsFormsApplication1.Forms.Doctor_Link;

namespace WindowsFormsApplication1.Forms
{
    public partial class Form1_PatientRec : Form
    {
        public Form1_PatientRec()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Naveed Rahaman\Desktop\New Lanka_Final Pro\WindowsFormsApplication1\New Lanka Hospital_23.mdb");
        private void btn_Save_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into PatientRecord(Doctor_ID,PatientName,RegistrationNo,Age,Gender,Occupation,LastVisit,Review)values('" + cmb_DocID.Text + "','" + txt_PDName.Text + "','" + txt_RegNo.Text + "','" + txt_Age.Text + "','" + cmb_Gen.Text + "','" + txt_Ocu.Text + "','" + dtp_LVisit.Text + "','" + txt_Review.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Save Successfully");
        }

        
        private void btn_Menu_Click(object sender, EventArgs e)
        {
            Form1_DocLink newform = new Form1_DocLink();
            newform.Show();
            this.Hide();
        }

        private void txt_PDName_TextChanged(object sender, EventArgs e)
        {

        }

        public OleDbParameter NewOleDBParameters { get; set; }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
