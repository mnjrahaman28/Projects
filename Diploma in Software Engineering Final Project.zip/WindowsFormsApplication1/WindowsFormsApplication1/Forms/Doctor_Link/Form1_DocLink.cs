﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1.Forms.Doctor_Link
{
    public partial class Form1_DocLink : Form
    {
        public Form1_DocLink()
        {
            InitializeComponent();
        }

        private void btn_PatRec_Click(object sender, EventArgs e)
        {
            Form1_PatientRec newform = new Form1_PatientRec();
            newform.Show();
            this.Hide();
        }

        private void btn_Prescription_Click(object sender, EventArgs e)
        {
            Form1_Prescription newform = new Form1_Prescription();
            newform.Show();
            this.Hide();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            DialogResult iLogin;

            iLogin = MessageBox.Show("Are you sure you want to go back to the Login System", "Hospital Management System",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            {
                Form1_Login newform = new Form1_Login();
                newform.Show();
                this.Hide();
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show(" Are you sure want to Exit", "Hospital Management System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
