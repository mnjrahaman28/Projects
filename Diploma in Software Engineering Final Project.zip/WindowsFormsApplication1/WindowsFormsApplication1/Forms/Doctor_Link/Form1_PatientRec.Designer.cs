﻿namespace WindowsFormsApplication1.Forms
{
    partial class Form1_PatientRec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Age = new System.Windows.Forms.TextBox();
            this.lbl_occupation = new System.Windows.Forms.Label();
            this.txt_Ocu = new System.Windows.Forms.TextBox();
            this.lbl_LVisit = new System.Windows.Forms.Label();
            this.txt_PDName = new System.Windows.Forms.TextBox();
            this.txt_RegNo = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_Review = new System.Windows.Forms.Label();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.txt_Review = new System.Windows.Forms.TextBox();
            this.dtp_LVisit = new System.Windows.Forms.DateTimePicker();
            this.cmb_Gen = new System.Windows.Forms.ComboBox();
            this.lbl_DocID = new System.Windows.Forms.Label();
            this.cmb_DocID = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 79);
            this.panel1.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(122, 39);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 31);
            this.label3.TabIndex = 1;
            this.label3.Text = "Patient Record";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(487, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital Mangement System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 309);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 155);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Patient Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 207);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Registration No:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 256);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Age";
            // 
            // txt_Age
            // 
            this.txt_Age.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Age.Location = new System.Drawing.Point(130, 250);
            this.txt_Age.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Age.Name = "txt_Age";
            this.txt_Age.Size = new System.Drawing.Size(200, 26);
            this.txt_Age.TabIndex = 18;
            this.txt_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_occupation
            // 
            this.lbl_occupation.AutoSize = true;
            this.lbl_occupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_occupation.Location = new System.Drawing.Point(11, 371);
            this.lbl_occupation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_occupation.Name = "lbl_occupation";
            this.lbl_occupation.Size = new System.Drawing.Size(76, 16);
            this.lbl_occupation.TabIndex = 22;
            this.lbl_occupation.Text = "Occupation";
            // 
            // txt_Ocu
            // 
            this.txt_Ocu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Ocu.Location = new System.Drawing.Point(126, 365);
            this.txt_Ocu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Ocu.Name = "txt_Ocu";
            this.txt_Ocu.Size = new System.Drawing.Size(202, 26);
            this.txt_Ocu.TabIndex = 21;
            // 
            // lbl_LVisit
            // 
            this.lbl_LVisit.AutoSize = true;
            this.lbl_LVisit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LVisit.Location = new System.Drawing.Point(13, 433);
            this.lbl_LVisit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_LVisit.Name = "lbl_LVisit";
            this.lbl_LVisit.Size = new System.Drawing.Size(61, 16);
            this.lbl_LVisit.TabIndex = 23;
            this.lbl_LVisit.Text = "Last Visit";
            // 
            // txt_PDName
            // 
            this.txt_PDName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PDName.Location = new System.Drawing.Point(128, 149);
            this.txt_PDName.Margin = new System.Windows.Forms.Padding(4);
            this.txt_PDName.Name = "txt_PDName";
            this.txt_PDName.Size = new System.Drawing.Size(202, 26);
            this.txt_PDName.TabIndex = 25;
            this.txt_PDName.TextChanged += new System.EventHandler(this.txt_PDName_TextChanged);
            // 
            // txt_RegNo
            // 
            this.txt_RegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_RegNo.Location = new System.Drawing.Point(129, 201);
            this.txt_RegNo.Name = "txt_RegNo";
            this.txt_RegNo.Size = new System.Drawing.Size(202, 26);
            this.txt_RegNo.TabIndex = 28;
            this.txt_RegNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(354, 265);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(86, 34);
            this.btn_Save.TabIndex = 30;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(354, 370);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(86, 34);
            this.btn_Exit.TabIndex = 32;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // lbl_Review
            // 
            this.lbl_Review.AutoSize = true;
            this.lbl_Review.Location = new System.Drawing.Point(13, 486);
            this.lbl_Review.Name = "lbl_Review";
            this.lbl_Review.Size = new System.Drawing.Size(53, 16);
            this.lbl_Review.TabIndex = 33;
            this.lbl_Review.Text = "Review";
            // 
            // btn_Menu
            // 
            this.btn_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(354, 147);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(86, 34);
            this.btn_Menu.TabIndex = 35;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = true;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // txt_Review
            // 
            this.txt_Review.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Review.Location = new System.Drawing.Point(127, 480);
            this.txt_Review.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Review.Name = "txt_Review";
            this.txt_Review.Size = new System.Drawing.Size(202, 26);
            this.txt_Review.TabIndex = 36;
            // 
            // dtp_LVisit
            // 
            this.dtp_LVisit.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_LVisit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_LVisit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_LVisit.Location = new System.Drawing.Point(126, 425);
            this.dtp_LVisit.MinDate = new System.DateTime(1930, 1, 31, 0, 0, 0, 0);
            this.dtp_LVisit.Name = "dtp_LVisit";
            this.dtp_LVisit.Size = new System.Drawing.Size(202, 26);
            this.dtp_LVisit.TabIndex = 37;
            this.dtp_LVisit.Value = new System.DateTime(2020, 2, 14, 12, 12, 39, 0);
            // 
            // cmb_Gen
            // 
            this.cmb_Gen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Gen.FormattingEnabled = true;
            this.cmb_Gen.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmb_Gen.Location = new System.Drawing.Point(131, 303);
            this.cmb_Gen.Name = "cmb_Gen";
            this.cmb_Gen.Size = new System.Drawing.Size(200, 28);
            this.cmb_Gen.TabIndex = 38;
            // 
            // lbl_DocID
            // 
            this.lbl_DocID.AutoSize = true;
            this.lbl_DocID.Location = new System.Drawing.Point(13, 107);
            this.lbl_DocID.Name = "lbl_DocID";
            this.lbl_DocID.Size = new System.Drawing.Size(64, 16);
            this.lbl_DocID.TabIndex = 39;
            this.lbl_DocID.Text = "Doctor ID";
            // 
            // cmb_DocID
            // 
            this.cmb_DocID.FormattingEnabled = true;
            this.cmb_DocID.Items.AddRange(new object[] {
            "Doc_101",
            "Doc_102",
            "Doc_103",
            "Doc_104",
            "Doc_105"});
            this.cmb_DocID.Location = new System.Drawing.Point(128, 104);
            this.cmb_DocID.Name = "cmb_DocID";
            this.cmb_DocID.Size = new System.Drawing.Size(200, 24);
            this.cmb_DocID.TabIndex = 40;
            // 
            // Form1_PatientRec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 547);
            this.Controls.Add(this.cmb_DocID);
            this.Controls.Add(this.lbl_DocID);
            this.Controls.Add(this.cmb_Gen);
            this.Controls.Add(this.dtp_LVisit);
            this.Controls.Add(this.txt_Review);
            this.Controls.Add(this.btn_Menu);
            this.Controls.Add(this.lbl_Review);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.txt_RegNo);
            this.Controls.Add(this.txt_PDName);
            this.Controls.Add(this.lbl_LVisit);
            this.Controls.Add(this.lbl_occupation);
            this.Controls.Add(this.txt_Ocu);
            this.Controls.Add(this.txt_Age);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1_PatientRec";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Age;
        private System.Windows.Forms.Label lbl_occupation;
        private System.Windows.Forms.TextBox txt_Ocu;
        private System.Windows.Forms.Label lbl_LVisit;
        private System.Windows.Forms.TextBox txt_PDName;
        private System.Windows.Forms.TextBox txt_RegNo;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_Review;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.TextBox txt_Review;
        private System.Windows.Forms.DateTimePicker dtp_LVisit;
        private System.Windows.Forms.ComboBox cmb_Gen;
        private System.Windows.Forms.Label lbl_DocID;
        private System.Windows.Forms.ComboBox cmb_DocID;
    }
}